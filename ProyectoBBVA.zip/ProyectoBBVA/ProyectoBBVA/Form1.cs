﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace ProyectoBBVA
{
    public partial class Form1 : Form
    {
        registro registro;

        consulta consulta;
        public Form1()
        {
            InitializeComponent();
            registro = new registro();
            registro.original = this;

            consulta= new consulta();
            consulta.original = this;
        }

        SqlConnection connection; 

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        public void conectar()
        {
            String sql = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\joabe\Documentos\ProyectoBBVA\ProyectoBBVA\empresa.mdf;Integrated Security=True";
            connection = new SqlConnection(sql);
            try
            {
                connection.Open();
                MessageBox.Show("Se abrio la conexion");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnconsultar_Click(object sender, EventArgs e)
        {

            String nombreusuario = txtusuario.Text;
            String contraseña = txtcontraseña.Text;
            String clienteabuscar = txtclienteabuscar.Text;
            
            try
            {
                conectar();
                
                SqlDataReader dataReader;
                string comandosql = "SELECT usuario,contrasena,perfil FROM trabajador WHERE usuario= '" + nombreusuario + "'";
                SqlCommand sentencia = new SqlCommand(comandosql, connection);
                dataReader = sentencia.ExecuteReader();
                while (dataReader.Read())
                {
                    string usuarioencontrado = "" + dataReader[0];
                    string contraseñaencontrada = "" + dataReader[1];

                    if (nombreusuario == usuarioencontrado)
                    {
                        if (contraseña == contraseñaencontrada)
                        {
                            txtusuarioresponsable.Text += dataReader[0];
                            txttipodeusuario.Text += dataReader[2];

                            if(txttipodeusuario.Text == "Manager")
                            {
                                StreamReader reader = new StreamReader("archivo.csv");
                                while (!reader.EndOfStream)
                                {
                                    var campo = reader.ReadLine().Split(',');
                                    if (campo[0] == clienteabuscar)
                                    {
                                        MessageBox.Show("Se encontro al cliente");
                                        txtidcliente.Text = campo[0];
                                        txtnombre.Text = campo[1];
                                        txtpaterno.Text = campo[2];
                                        txtmaterno.Text = campo[3];
                                        txtfechanac.Text = campo[4];
                                        txtsexo.Text = campo[5];
                                    }
                                }
                                reader.Close();
                            }

                            if (txttipodeusuario.Text == "Validador")
                            {
                                int camposvacios = 0;
                                
                                StreamReader reader = new StreamReader("archivo.csv");
                                while (!reader.EndOfStream)
                                {
                                    var campo = reader.ReadLine().Split(',');
                                    if (campo[0] == clienteabuscar)
                                    {
                                        MessageBox.Show("Se encontro al cliente");
                                        txtidcliente.Text = campo[0];
                                        txtnombre.Text = campo[1];
                                        txtpaterno.Text = ofuscada(campo[2]);
                                        txtmaterno.Text = campo[3];
                                        txtfechanac.Text = ofuscada(campo[4]);
                                        txtsexo.Text = campo[5];

                                        for(int cont=0;cont<6;cont++)
                                        {
                                            if(campo[cont] == "")
                                            {
                                                camposvacios++;
                                            }
                                        }
                                        txtcamposvacios.Text += camposvacios;
                                    }
                                }
                                reader.Close();
                            }

                            if (txttipodeusuario.Text == "Restringido")
                            {
                                StreamReader reader = new StreamReader("archivo.csv");
                                while (!reader.EndOfStream)
                                {
                                    var campo = reader.ReadLine().Split(',');
                                    if (campo[0] == clienteabuscar)
                                    {
                                        MessageBox.Show("Se encontro al cliente");
                                        txtidcliente.Text = campo[0];
                                        txtnombre.Text = campo[1];
                                        txtmaterno.Text = campo[3];
                                        txtsexo.Text = campo[5];
                                    }
                                }
                                reader.Close();
                            }

                        }
                        else
                        {
                            MessageBox.Show("La contraseña es incorrecta");
                        }  
                    }
                                        
                }

                dataReader.Close();
                sentencia.Dispose();
                connection.Close();

            }
            catch (SqlException mensajeerrror)
            {
                MessageBox.Show(mensajeerrror.Message);
            }

            /*this.Visible = false;
            consulta.Visible = true;*/

        }

        public string ofuscada(string texto)
        {
            string textoofuscado="";
            if (texto != "")
            {
                int longitud = texto.Length;
                string tres = texto.Substring(0, 3);
                int caracteresfaltante = longitud - 3;
                string asteriscos = "";

                for (int i = 0; i < caracteresfaltante; i++)
                {
                    asteriscos = asteriscos + "*";
                }
                textoofuscado = tres + asteriscos;

            }
            return textoofuscado;


        }

        private void btnregistrarse_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            registro.Visible = true;
        }
    }
}


