﻿namespace ProyectoBBVA
{
    partial class registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtusuario = new System.Windows.Forms.TextBox();
            this.lblusuario = new System.Windows.Forms.Label();
            this.lblcontraseña = new System.Windows.Forms.Label();
            this.txtcontraseña = new System.Windows.Forms.TextBox();
            this.lblnombrecomp = new System.Windows.Forms.Label();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.lblarea = new System.Windows.Forms.Label();
            this.txtarea = new System.Windows.Forms.TextBox();
            this.lblubicacion = new System.Windows.Forms.Label();
            this.txtubicacion = new System.Windows.Forms.TextBox();
            this.lblsegmento = new System.Windows.Forms.Label();
            this.txtsegmento = new System.Windows.Forms.TextBox();
            this.lblperfil = new System.Windows.Forms.Label();
            this.txtperfil = new System.Windows.Forms.TextBox();
            this.btnregistro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(348, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registrarse";
            // 
            // txtusuario
            // 
            this.txtusuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusuario.Location = new System.Drawing.Point(276, 84);
            this.txtusuario.Name = "txtusuario";
            this.txtusuario.Size = new System.Drawing.Size(340, 34);
            this.txtusuario.TabIndex = 1;
            // 
            // lblusuario
            // 
            this.lblusuario.AutoSize = true;
            this.lblusuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusuario.Location = new System.Drawing.Point(127, 89);
            this.lblusuario.Name = "lblusuario";
            this.lblusuario.Size = new System.Drawing.Size(96, 29);
            this.lblusuario.TabIndex = 2;
            this.lblusuario.Text = "Usuario";
            // 
            // lblcontraseña
            // 
            this.lblcontraseña.AutoSize = true;
            this.lblcontraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontraseña.Location = new System.Drawing.Point(127, 152);
            this.lblcontraseña.Name = "lblcontraseña";
            this.lblcontraseña.Size = new System.Drawing.Size(136, 29);
            this.lblcontraseña.TabIndex = 4;
            this.lblcontraseña.Text = "Contraseña";
            // 
            // txtcontraseña
            // 
            this.txtcontraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcontraseña.Location = new System.Drawing.Point(276, 147);
            this.txtcontraseña.Name = "txtcontraseña";
            this.txtcontraseña.Size = new System.Drawing.Size(340, 34);
            this.txtcontraseña.TabIndex = 3;
            // 
            // lblnombrecomp
            // 
            this.lblnombrecomp.AutoSize = true;
            this.lblnombrecomp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnombrecomp.Location = new System.Drawing.Point(127, 204);
            this.lblnombrecomp.Name = "lblnombrecomp";
            this.lblnombrecomp.Size = new System.Drawing.Size(101, 29);
            this.lblnombrecomp.TabIndex = 6;
            this.lblnombrecomp.Text = "Nombre";
            // 
            // txtnombre
            // 
            this.txtnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnombre.Location = new System.Drawing.Point(276, 199);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(340, 34);
            this.txtnombre.TabIndex = 5;
            // 
            // lblarea
            // 
            this.lblarea.AutoSize = true;
            this.lblarea.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblarea.Location = new System.Drawing.Point(127, 257);
            this.lblarea.Name = "lblarea";
            this.lblarea.Size = new System.Drawing.Size(63, 29);
            this.lblarea.TabIndex = 8;
            this.lblarea.Text = "Area";
            // 
            // txtarea
            // 
            this.txtarea.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtarea.Location = new System.Drawing.Point(276, 252);
            this.txtarea.Name = "txtarea";
            this.txtarea.Size = new System.Drawing.Size(340, 34);
            this.txtarea.TabIndex = 7;
            // 
            // lblubicacion
            // 
            this.lblubicacion.AutoSize = true;
            this.lblubicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblubicacion.Location = new System.Drawing.Point(127, 316);
            this.lblubicacion.Name = "lblubicacion";
            this.lblubicacion.Size = new System.Drawing.Size(120, 29);
            this.lblubicacion.TabIndex = 10;
            this.lblubicacion.Text = "Ubicacion";
            // 
            // txtubicacion
            // 
            this.txtubicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtubicacion.Location = new System.Drawing.Point(276, 311);
            this.txtubicacion.Name = "txtubicacion";
            this.txtubicacion.Size = new System.Drawing.Size(340, 34);
            this.txtubicacion.TabIndex = 9;
            // 
            // lblsegmento
            // 
            this.lblsegmento.AutoSize = true;
            this.lblsegmento.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsegmento.Location = new System.Drawing.Point(127, 368);
            this.lblsegmento.Name = "lblsegmento";
            this.lblsegmento.Size = new System.Drawing.Size(124, 29);
            this.lblsegmento.TabIndex = 12;
            this.lblsegmento.Text = "Segmento";
            // 
            // txtsegmento
            // 
            this.txtsegmento.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsegmento.Location = new System.Drawing.Point(276, 363);
            this.txtsegmento.Name = "txtsegmento";
            this.txtsegmento.Size = new System.Drawing.Size(340, 34);
            this.txtsegmento.TabIndex = 11;
            // 
            // lblperfil
            // 
            this.lblperfil.AutoSize = true;
            this.lblperfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblperfil.Location = new System.Drawing.Point(127, 428);
            this.lblperfil.Name = "lblperfil";
            this.lblperfil.Size = new System.Drawing.Size(69, 29);
            this.lblperfil.TabIndex = 14;
            this.lblperfil.Text = "Perfil";
            // 
            // txtperfil
            // 
            this.txtperfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtperfil.Location = new System.Drawing.Point(276, 423);
            this.txtperfil.Name = "txtperfil";
            this.txtperfil.Size = new System.Drawing.Size(340, 34);
            this.txtperfil.TabIndex = 13;
            // 
            // btnregistro
            // 
            this.btnregistro.Location = new System.Drawing.Point(654, 449);
            this.btnregistro.Name = "btnregistro";
            this.btnregistro.Size = new System.Drawing.Size(137, 56);
            this.btnregistro.TabIndex = 15;
            this.btnregistro.Text = "Registrarse";
            this.btnregistro.UseVisualStyleBackColor = true;
            this.btnregistro.Click += new System.EventHandler(this.btnregistro_Click);
            // 
            // registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 530);
            this.Controls.Add(this.btnregistro);
            this.Controls.Add(this.lblperfil);
            this.Controls.Add(this.txtperfil);
            this.Controls.Add(this.lblsegmento);
            this.Controls.Add(this.txtsegmento);
            this.Controls.Add(this.lblubicacion);
            this.Controls.Add(this.txtubicacion);
            this.Controls.Add(this.lblarea);
            this.Controls.Add(this.txtarea);
            this.Controls.Add(this.lblnombrecomp);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.lblcontraseña);
            this.Controls.Add(this.txtcontraseña);
            this.Controls.Add(this.lblusuario);
            this.Controls.Add(this.txtusuario);
            this.Controls.Add(this.label1);
            this.Name = "registro";
            this.Text = "Registro";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtusuario;
        private System.Windows.Forms.Label lblusuario;
        private System.Windows.Forms.Label lblcontraseña;
        private System.Windows.Forms.TextBox txtcontraseña;
        private System.Windows.Forms.Label lblnombrecomp;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Label lblarea;
        private System.Windows.Forms.TextBox txtarea;
        private System.Windows.Forms.Label lblubicacion;
        private System.Windows.Forms.TextBox txtubicacion;
        private System.Windows.Forms.Label lblsegmento;
        private System.Windows.Forms.TextBox txtsegmento;
        private System.Windows.Forms.Label lblperfil;
        private System.Windows.Forms.TextBox txtperfil;
        private System.Windows.Forms.Button btnregistro;
    }
}