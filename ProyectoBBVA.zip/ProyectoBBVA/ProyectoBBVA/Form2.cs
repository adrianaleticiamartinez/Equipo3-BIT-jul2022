﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProyectoBBVA
{

    
    public partial class registro : Form
    {

        public Form1 original;

        SqlConnection connection;
        public registro()
        {
            InitializeComponent();
        }

        public void conectar()
        {
            String sql = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\joabe\Documentos\Visual\ProyectoBBVA\ProyectoBBVA\empresa.mdf;Integrated Security =True";
            connection = new SqlConnection(sql);
            try
            {
                connection.Open();
                MessageBox.Show("Se abrio la conexion");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public bool validar(char segmento)
        {
            if (segmento == '0' || segmento == '1'  || segmento == '2')
            { 
                return true;
            }
            else
            {
                MessageBox.Show("El segmento no puede tener ese valor");
                return false;

            }
        }

        private void btnregistro_Click(object sender, EventArgs e)
        {
          
            String usuario = txtusuario.Text;
            String contrasena = txtcontraseña.Text;
            String nombre = txtnombre.Text;
            String area = txtarea.Text;
            String ubicacion = txtubicacion.Text;
            Char segmento = char.Parse(txtsegmento.Text);
            String perfil = txtperfil.Text;

            
            if(validar(segmento) == false)
            {
                MessageBox.Show("No se pudo agregar el nuevo empleado");
            }
            else
            {
                try
                {
                    conectar();
                    SqlCommand comando;
                    String sql = "insert into trabajador(usuario,contrasena,nombre,area,ubicacion,segmento,perfil) values(@usuario,@contrasena,@nombre,@area,@ubicacion,@segmento,@perfil)";
                    comando = new SqlCommand(sql, connection);
                    comando.Parameters.Add(new SqlParameter("usuario", usuario));
                    comando.Parameters.Add(new SqlParameter("contrasena", contrasena));
                    comando.Parameters.Add(new SqlParameter("nombre", nombre));
                    comando.Parameters.Add(new SqlParameter("area", area));
                    comando.Parameters.Add(new SqlParameter("ubicacion", ubicacion));
                    comando.Parameters.Add(new SqlParameter("segmento", segmento));
                    comando.Parameters.Add(new SqlParameter("perfil", perfil));
                    MessageBox.Show("Se ingresaron correctamente los datos");
                    int resultado = comando.ExecuteNonQuery();
                    if (resultado <= 0)
                    {
                        MessageBox.Show("Error insertando en la base de datos");
                    }
                    comando.Dispose();
                    connection.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


                this.Visible = false;
                Form1 form = new Form1();
                form.Visible = true;
            }
            
            


        }
    }
}
