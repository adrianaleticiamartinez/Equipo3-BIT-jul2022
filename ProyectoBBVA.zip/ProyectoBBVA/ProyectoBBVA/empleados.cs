﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoBBVA
{
    internal class empleados
    {
        String usuario, contraseña, nombre, area, ubicacion, segmento, perfil;


    }
}
